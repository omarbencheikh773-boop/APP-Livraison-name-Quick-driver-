package com.example.myfirst_app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etFullName = findViewById<EditText>(R.id.etFullName)
        val etRegEmail = findViewById<EditText>(R.id.etRegEmail)
        val etAddress = findViewById<EditText>(R.id.etAddress)
        val etPhone = findViewById<EditText>(R.id.etPhone)
        val etAge = findViewById<EditText>(R.id.etAge)
        val etRegPassword = findViewById<EditText>(R.id.etRegPassword)
        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val tvBackToLogin = findViewById<TextView>(R.id.tvBackToLogin)

        btnRegister.setOnClickListener {
            val name = etFullName.text.toString().trim()
            val email = etRegEmail.text.toString().trim()
            val address = etAddress.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val age = etAge.text.toString().trim()
            val pass = etRegPassword.text.toString().trim()

            if (name.isNotEmpty() && email.isNotEmpty() && address.isNotEmpty() && phone.isNotEmpty() && age.isNotEmpty() && pass.isNotEmpty()) {

                // حفظ البيانات بـ Keys واضحة ومضبوطة
                val sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
                with(sharedPreferences.edit()) {
                    putString("KEY_NAME", name)
                    putString("KEY_EMAIL", email)
                    putString("KEY_ADDRESS", address)
                    putString("KEY_PHONE", phone)
                    putString("KEY_AGE", age)
                    putString("KEY_PASS", pass)
                    apply()
                }

                Toast.makeText(this, "Compte créé avec succès !", Toast.LENGTH_SHORT).show()

                // رجّعو لصفحة Login
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show()
            }
        }

        tvBackToLogin.setOnClickListener {
            finish()
        }
    }
}