package com.example.myfirst_app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // تعريف زر الرجوع كـ TextView (حسب الـ XML الجديد)
        val btnBack = findViewById<TextView>(R.id.btnBack)
        val tvProfileName = findViewById<TextView>(R.id.tvProfileName)
        val tvProfileEmail = findViewById<TextView>(R.id.tvProfileEmail)
        val tvProfileAddress = findViewById<TextView>(R.id.tvProfileAddress)
        val tvProfilePhone = findViewById<TextView>(R.id.tvProfilePhone)
        val tvProfileAge = findViewById<TextView>(R.id.tvProfileAge)
        val btnQrCode = findViewById<Button>(R.id.btnQrCode)
        val layoutOrderHistory = findViewById<LinearLayout>(R.id.layoutOrderHistory)

        // 🚀 استجابة فورية 100% بدون أي Animation تقيلة أو تأخير
        btnBack.setOnClickListener {
            finish()
            overridePendingTransition(0, 0)
        }

        // جلب البيانات المسجلة من SharedPreferences وعرضها بسلاسة
        val sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val name = sharedPreferences.getString("KEY_NAME", "Non spécifié")
        val email = sharedPreferences.getString("KEY_EMAIL", "Non spécifié")
        val address = sharedPreferences.getString("KEY_ADDRESS", "Non spécifié")
        val phone = sharedPreferences.getString("KEY_PHONE", "Non spécifié")
        val age = sharedPreferences.getString("KEY_AGE", "Non spécifié")

        tvProfileName.text = name
        tvProfileEmail.text = email
        tvProfileAddress.text = address
        tvProfilePhone.text = phone
        tvProfileAge.text = if (age != "Non spécifié") "$age ans" else age

        // 🚀 توليد وعرض الـ QR Code عند الضغط على الزر (تمت إزالة const بنجاح)
        btnQrCode.setOnClickListener {
            val qrData = "Nom: $name\nEmail: $email\nTél: $phone"
            val qrBitmap = generateQRCode(qrData)

            val qrImageView = ImageView(this).apply {
                setImageBitmap(qrBitmap)
                setPadding(40, 40, 40, 40)
            }

            AlertDialog.Builder(this)
                .setTitle("Mon QR Code Livreur")
                .setView(qrImageView)
                .setPositiveButton("Fermer") { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }

        layoutOrderHistory.setOnClickListener {
            Toast.makeText(this, "Historique des commandes", Toast.LENGTH_SHORT).show()
        }
    }

    // 📐 دالة لتوليد الـ QR Code كصورة Bitmap مباشرة عبر مكتبة ZXing
    private fun generateQRCode(text: String): Bitmap {
        val width = 500
        val height = 500
        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, width, height)
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        for (x in 0 until width) {
            for (y in 0 until height) {
                bmp.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
            }
        }
        return bmp
    }
}