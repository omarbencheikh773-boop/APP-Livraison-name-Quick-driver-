package com.example.myfirst_app

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OrdersActivity : AppCompatActivity() {

    private lateinit var tabAvailable: TextView
    private lateinit var tabMyOrders: TextView
    private lateinit var tabRecuperer: TextView

    private lateinit var lineAvailable: View
    private lateinit var lineMyOrders: View
    private lateinit var lineRecuperer: View

    private lateinit var layoutTabAvailable: LinearLayout
    private lateinit var layoutTabMyOrders: LinearLayout
    private lateinit var layoutTabRecuperer: LinearLayout

    data class OrderModel(
        val orderId: String,
        val restaurant: String,
        val amount: String,
        val date: String,
        var status: String = "Disponible"
    )

    companion object {
        val availableOrdersList = mutableListOf<OrderModel>()
        val acceptedOrdersList = mutableListOf<OrderModel>()
        val recupererOrdersList = mutableListOf<OrderModel>()

        var isOrderValidated = false
        var totalEarnings: Double = 0.0
        var completedOrdersCount: Int = 0
        var isDriverOnline = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var currentTab = "Available"
    private var isSimulatingOrders = false

    private val poolToSimulate = listOf(
        OrderModel("N° PZH-881203", "Pizza Hut Agdal", "215 MAD", "07/11/2026", "Disponible"),
        OrderModel("N° MCD-992110", "McDonald's Agdal", "145 MAD", "07/11/2026", "Disponible"),
        OrderModel("N° KFC-441823", "KFC Hay Riad", "210 MAD", "07/11/2026", "Disponible"),
        OrderModel("N° STB-778201", "Starbucks Souissi", "95 MAD", "07/11/2026", "Disponible"),
        OrderModel("N° BKG-112349", "Burger King Rabat", "180 MAD", "07/11/2026", "Disponible"),
        OrderModel("N° TCS-554190", "Tacos de Lyon Agdal", "120 MAD", "07/11/2026", "Disponible")
    )
    private var simulateIndex = 0

    private val simulateRunnable = object : Runnable {
        override fun run() {
            if (isDriverOnline && isSimulatingOrders && currentTab == "Available") {
                if (availableOrdersList.size < 3 && simulateIndex < poolToSimulate.size) {
                    val nextOrder = poolToSimulate[simulateIndex]
                    if (!availableOrdersList.any { it.orderId == nextOrder.orderId } &&
                        !acceptedOrdersList.any { it.orderId == nextOrder.orderId } &&
                        !recupererOrdersList.any { it.orderId == nextOrder.orderId }) {
                        availableOrdersList.add(nextOrder)
                        showAvailableOrders()
                    }
                    simulateIndex++
                }
                handler.postDelayed(this, 2000)
            } else if (!isDriverOnline) {
                stopSimulation()
                availableOrdersList.clear()
                showAvailableOrders()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_orders)

        tabAvailable = findViewById(R.id.tabAvailable)
        tabMyOrders = findViewById(R.id.tabMyOrders)
        tabRecuperer = findViewById(R.id.tabRecuperer)

        lineAvailable = findViewById(R.id.lineAvailable)
        lineMyOrders = findViewById(R.id.lineMyOrders)
        lineRecuperer = findViewById(R.id.lineRecuperer)

        layoutTabAvailable = findViewById(R.id.layoutTabAvailable)
        layoutTabMyOrders = findViewById(R.id.layoutTabMyOrders)
        layoutTabRecuperer = findViewById(R.id.layoutTabRecuperer)

        isDriverOnline = intent.getBooleanExtra("IS_ONLINE", isDriverOnline)

        if (!isDriverOnline) {
            availableOrdersList.clear()
        }

        val orderId = intent.getStringExtra("ORDER_ID")
        val restaurantName = intent.getStringExtra("RESTAURANT_NAME")
        val amount = intent.getStringExtra("AMOUNT")
        val orderStatus = intent.getStringExtra("ORDER_STATUS")

        if (orderId != null && restaurantName != null && amount != null) {
            val currentDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
            val finalStatus = if (orderStatus?.contains("Refus", true) == true) "Refusé" else "Acceptée"

            val exists = acceptedOrdersList.any { it.orderId == orderId }
            if (!exists) {
                val newOrder = OrderModel(orderId, restaurantName, amount, currentDate, finalStatus)
                acceptedOrdersList.add(newOrder)
            }
        }

        layoutTabAvailable.setOnClickListener {
            currentTab = "Available"
            if (isDriverOnline) startSimulation()
            showAvailableOrders()
        }
        layoutTabMyOrders.setOnClickListener {
            currentTab = "MyOrders"
            stopSimulation()
            showMyOrders()
        }
        layoutTabRecuperer.setOnClickListener {
            currentTab = "Recuperer"
            stopSimulation()
            showRecuperer()
        }

        val btnNotification = findViewById<ImageView>(R.id.btnNotification)
        btnNotification?.setColorFilter(Color.parseColor("#FF5722"))
        btnNotification?.setOnClickListener {
            Toast.makeText(this, "Notifications", Toast.LENGTH_SHORT).show()
        }

        val backButton = findViewById<View>(R.id.btnBack)
        if (backButton is TextView) {
            backButton.text = "←"
            backButton.textSize = 28f
            backButton.setTextColor(Color.parseColor("#FF5722"))
        } else if (backButton is ImageView) {
            backButton.setColorFilter(Color.parseColor("#FF5722"))
        }
        backButton?.setOnClickListener {
            stopSimulation()
            finish()
        }

        if (isDriverOnline) {
            startSimulation()
        }

        showMyOrders()
    }

    private fun startSimulation() {
        if (!isSimulatingOrders) {
            isSimulatingOrders = true
            handler.post(simulateRunnable)
        }
    }

    private fun stopSimulation() {
        isSimulatingOrders = false
        handler.removeCallbacks(simulateRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopSimulation()
    }

    private fun showAvailableOrders() {
        currentTab = "Available"
        tabAvailable.setTextColor(Color.parseColor("#FF5722"))
        lineAvailable.setBackgroundColor(Color.parseColor("#FF5722"))
        tabMyOrders.setTextColor(Color.GRAY)
        lineMyOrders.setBackgroundColor(Color.TRANSPARENT)
        tabRecuperer.setTextColor(Color.GRAY)
        lineRecuperer.setBackgroundColor(Color.TRANSPARENT)

        val listView = findViewById<ListView>(R.id.listViewOrders)
        if (listView != null) {
            val adapter = object : ArrayAdapter<OrderModel>(this, R.layout.item_order, availableOrdersList) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_order, parent, false)
                    val order = getItem(position)

                    val tvOrderId = view.findViewById<TextView>(R.id.tvOrderId)
                    val tvDate = view.findViewById<TextView>(R.id.tvDate)
                    val tvRestaurant = view.findViewById<TextView>(R.id.tvRestaurant)
                    val tvAmount = view.findViewById<TextView>(R.id.tvAmount)
                    val tvStatusBadge = view.findViewById<TextView>(R.id.tvStatusBadge)
                    val btnValidate = view.findViewById<Button>(R.id.btnValidateOrder)

                    tvOrderId.text = order?.orderId
                    tvDate.text = order?.date
                    tvRestaurant.text = order?.restaurant
                    tvAmount.text = order?.amount

                    tvStatusBadge.text = "Disponible"
                    tvStatusBadge.setBackgroundColor(Color.parseColor("#FF5722"))

                    btnValidate.text = "Accepter"
                    btnValidate.visibility = View.VISIBLE
                    val acceptBg = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = 50f
                        setColor(Color.parseColor("#FF5722"))
                    }
                    btnValidate.background = acceptBg
                    btnValidate.setTextColor(Color.WHITE)

                    val parentLayout = btnValidate.parent as? ViewGroup
                    var btnRefuse = parentLayout?.findViewWithTag<Button>("BTN_REFUSE_TAG")
                    val existingNotValid = parentLayout?.findViewWithTag<Button>("BTN_NOT_VALID_TAG")
                    if (existingNotValid != null) parentLayout.removeView(existingNotValid)

                    if (btnRefuse == null && parentLayout != null) {
                        btnRefuse = Button(context).apply {
                            tag = "BTN_REFUSE_TAG"
                            text = "Refuser"
                            setTextColor(Color.BLACK)
                            textSize = 15f
                            val refuseBg = GradientDrawable().apply {
                                shape = GradientDrawable.RECTANGLE
                                cornerRadius = 50f
                                setStroke(3, Color.parseColor("#B0BEC5"))
                                setColor(Color.WHITE)
                            }
                            background = refuseBg
                            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 130).apply {
                                setMargins(0, 15, 0, 0)
                            }
                        }
                        parentLayout.addView(btnRefuse)
                    }

                    btnValidate.setOnClickListener {
                        if (order != null) {
                            availableOrdersList.remove(order)
                            order.status = "Acceptée"
                            if (!acceptedOrdersList.any { it.orderId == order.orderId }) {
                                acceptedOrdersList.add(order)
                            }
                            notifyDataSetChanged()
                            Toast.makeText(context, "Commande acceptée !", Toast.LENGTH_SHORT).show()
                        }
                    }

                    btnRefuse?.setOnClickListener {
                        if (order != null) {
                            val reasons = arrayOf(
                                "Restaurant trop éloigné",
                                "Problème de circulation / Embouteillage",
                                "Temps d'attente estimé trop long",
                                "Autre raison"
                            )

                            AlertDialog.Builder(context)
                                .setTitle("Motif de refus de la commande")
                                .setItems(reasons) { _, which ->
                                    val selectedReason = reasons[which]

                                    availableOrdersList.remove(order)
                                    order.status = "Refusé"
                                    if (!acceptedOrdersList.any { it.orderId == order.orderId }) {
                                        acceptedOrdersList.add(order)
                                    }

                                    notifyDataSetChanged()
                                    Toast.makeText(context, "Refusé : $selectedReason", Toast.LENGTH_LONG).show()
                                }
                                .setNegativeButton("Annuler", null)
                                .show()
                        }
                    }

                    return view
                }
            }
            listView.adapter = adapter
        }
    }

    private fun showMyOrders() {
        currentTab = "MyOrders"
        tabMyOrders.setTextColor(Color.parseColor("#FF5722"))
        lineMyOrders.setBackgroundColor(Color.parseColor("#FF5722"))
        tabAvailable.setTextColor(Color.GRAY)
        lineAvailable.setBackgroundColor(Color.TRANSPARENT)
        tabRecuperer.setTextColor(Color.GRAY)
        lineRecuperer.setBackgroundColor(Color.TRANSPARENT)

        val listView = findViewById<ListView>(R.id.listViewOrders)
        if (listView != null) {
            val adapter = object : ArrayAdapter<OrderModel>(this, R.layout.item_order, acceptedOrdersList) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_order, parent, false)
                    val order = getItem(position)

                    val tvOrderId = view.findViewById<TextView>(R.id.tvOrderId)
                    val tvDate = view.findViewById<TextView>(R.id.tvDate)
                    val tvRestaurant = view.findViewById<TextView>(R.id.tvRestaurant)
                    val tvAmount = view.findViewById<TextView>(R.id.tvAmount)
                    val tvStatusBadge = view.findViewById<TextView>(R.id.tvStatusBadge)
                    val btnValidate = view.findViewById<Button>(R.id.btnValidateOrder)

                    val parentLayout = btnValidate.parent as? ViewGroup
                    val existingRefuseBtn = parentLayout?.findViewWithTag<Button>("BTN_REFUSE_TAG")
                    if (existingRefuseBtn != null) parentLayout.removeView(existingRefuseBtn)

                    tvOrderId.text = order?.orderId
                    tvDate.text = order?.date
                    tvRestaurant.text = order?.restaurant
                    tvAmount.text = order?.amount

                    var btnNotValid = parentLayout?.findViewWithTag<Button>("BTN_NOT_VALID_TAG")
                    if (btnNotValid == null && parentLayout != null) {
                        btnNotValid = Button(context).apply {
                            tag = "BTN_NOT_VALID_TAG"
                            text = "N'est pas validé"
                            setTextColor(Color.BLACK)
                            textSize = 15f
                            val notValidBg = GradientDrawable().apply {
                                shape = GradientDrawable.RECTANGLE
                                cornerRadius = 50f
                                setStroke(3, Color.parseColor("#B0BEC5"))
                                setColor(Color.WHITE)
                            }
                            background = notValidBg
                            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 130).apply {
                                setMargins(0, 15, 0, 0)
                            }
                        }
                        parentLayout.addView(btnNotValid)
                    }

                    if (order?.status == "Refusé") {
                        tvStatusBadge.text = "Refusé"
                        tvStatusBadge.setBackgroundColor(Color.parseColor("#D32F2F"))
                        btnValidate.visibility = View.GONE
                        btnNotValid?.visibility = View.GONE
                    } else if (order?.status == "Validée") {
                        tvStatusBadge.text = "Validée"
                        tvStatusBadge.setBackgroundColor(Color.parseColor("#00E676"))
                        btnValidate.visibility = View.GONE
                        btnNotValid?.visibility = View.GONE
                    } else {
                        tvStatusBadge.text = "Acceptée"
                        tvStatusBadge.setBackgroundColor(Color.parseColor("#FF5722"))
                        btnValidate.visibility = View.VISIBLE
                        btnNotValid?.visibility = View.VISIBLE
                        btnValidate.text = "Valider"

                        val validateBg = GradientDrawable().apply {
                            shape = GradientDrawable.RECTANGLE
                            cornerRadius = 50f
                            setColor(Color.parseColor("#FF5722"))
                        }
                        btnValidate.background = validateBg
                        btnValidate.setTextColor(Color.WHITE)
                    }

                    btnValidate.setOnClickListener {
                        if (order != null) {
                            order.status = "Validée"
                            isOrderValidated = true

                            val cleanAmount = order.amount.replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: 0.0
                            totalEarnings += cleanAmount
                            completedOrdersCount++

                            notifyDataSetChanged()
                            Toast.makeText(context, "Commande validée !", Toast.LENGTH_SHORT).show()
                        }
                    }

                    btnNotValid?.setOnClickListener {
                        if (order != null) {
                            acceptedOrdersList.remove(order)
                            order.status = "Non validé"
                            if (!recupererOrdersList.any { it.orderId == order.orderId }) {
                                recupererOrdersList.add(order)
                            }
                            isOrderValidated = true

                            notifyDataSetChanged()
                            Toast.makeText(context, "Transféré vers Récupérer !", Toast.LENGTH_SHORT).show()
                        }
                    }

                    return view
                }
            }
            listView.adapter = adapter
        }
    }

    private fun showRecuperer() {
        currentTab = "Recuperer"
        tabRecuperer.setTextColor(Color.parseColor("#FF5722"))
        lineRecuperer.setBackgroundColor(Color.parseColor("#FF5722"))
        tabAvailable.setTextColor(Color.GRAY)
        lineAvailable.setBackgroundColor(Color.TRANSPARENT)
        tabMyOrders.setTextColor(Color.GRAY)
        lineMyOrders.setBackgroundColor(Color.TRANSPARENT)

        val listView = findViewById<ListView>(R.id.listViewOrders)
        if (listView != null) {
            val adapter = object : ArrayAdapter<OrderModel>(this, R.layout.item_order, recupererOrdersList) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_order, parent, false)
                    val order = getItem(position)

                    val tvOrderId = view.findViewById<TextView>(R.id.tvOrderId)
                    val tvDate = view.findViewById<TextView>(R.id.tvDate)
                    val tvRestaurant = view.findViewById<TextView>(R.id.tvRestaurant)
                    val tvAmount = view.findViewById<TextView>(R.id.tvAmount)
                    val tvStatusBadge = view.findViewById<TextView>(R.id.tvStatusBadge)
                    val btnValidate = view.findViewById<Button>(R.id.btnValidateOrder)

                    val parentLayout = btnValidate.parent as? ViewGroup
                    val existingRefuseBtn = parentLayout?.findViewWithTag<Button>("BTN_REFUSE_TAG")
                    val existingNotValidBtn = parentLayout?.findViewWithTag<Button>("BTN_NOT_VALID_TAG")
                    if (existingRefuseBtn != null) parentLayout.removeView(existingRefuseBtn)
                    if (existingNotValidBtn != null) parentLayout.removeView(existingNotValidBtn)

                    tvOrderId.text = order?.orderId
                    tvDate.text = order?.date
                    tvRestaurant.text = order?.restaurant
                    tvAmount.text = order?.amount

                    tvStatusBadge.text = order?.status ?: "Récupérée"
                    tvStatusBadge.setBackgroundColor(Color.parseColor("#00E676"))
                    btnValidate.visibility = View.GONE

                    return view
                }
            }
            listView.adapter = adapter
        }
    }
}