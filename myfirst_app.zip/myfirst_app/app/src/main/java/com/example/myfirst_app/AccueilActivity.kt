package com.example.myfirst_app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AccueilActivity : AppCompatActivity() {

    private var totalOrders = 0
    private lateinit var tvOrdersCount: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_accueil)

        val btnGoOnline = findViewById<Button>(R.id.btnGoOnline)
        tvOrdersCount = findViewById(R.id.tvOrdersCount)

        updateOrdersDisplay()

        btnGoOnline?.setOnClickListener {
            // فتح OrdersActivity مباشرة لتفادي أي خطأ في تعريف MainActivity
            val intent = Intent(this, OrdersActivity::class.java)
            intent.putExtra("IS_ONLINE", true)
            startActivity(intent)
            Toast.makeText(this, "En ligne - Commandes", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addNewOrder() {
        totalOrders++
        updateOrdersDisplay()
    }

    private fun updateOrdersDisplay() {
        tvOrdersCount?.text = "$totalOrders orders"
    }
}