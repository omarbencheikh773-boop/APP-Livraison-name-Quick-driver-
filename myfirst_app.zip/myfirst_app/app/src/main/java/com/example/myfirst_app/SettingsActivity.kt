package com.example.myfirst_app

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        val layoutLanguage = findViewById<LinearLayout>(R.id.layoutLanguage)

        btnBack.setOnClickListener { finish() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finish() }
        })

        layoutLanguage.setOnClickListener {
            val languages = arrayOf("Français", "English", "العربية")
            val languageCodes = arrayOf("fr", "en", "ar")

            AlertDialog.Builder(this)
                .setTitle(getString(R.string.dialog_title))
                .setItems(languages) { _, which ->
                    val selectedCode = languageCodes[which]
                    val appLocale = LocaleListCompat.forLanguageTags(selectedCode)
                    AppCompatDelegate.setApplicationLocales(appLocale)

                    val intent = packageManager.getLaunchIntentForPackage(packageName)
                    intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    startActivity(intent)
                    finish()
                }
                .setNegativeButton(getString(R.string.btn_close)) { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }
    }
}