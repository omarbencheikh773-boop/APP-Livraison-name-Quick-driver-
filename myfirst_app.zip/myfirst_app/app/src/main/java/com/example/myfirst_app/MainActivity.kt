package com.example.myfirst_app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var drawerLayout: DrawerLayout
    private var currentPolyline: Polyline? = null
    private val currentMarkers = mutableListOf<Marker>()
    private var isOnline = false
    private var hasActiveOrder = false

    private var driverPosition = LatLng(33.9580, -6.8830)

    private var tvWellDoneAmount: TextView? = null
    private var tvTodayProgressOrders: TextView? = null
    private lateinit var btnOnline: Button

    private lateinit var layoutActiveTripPanel: View
    private lateinit var tvChrono: TextView
    private lateinit var tvDistance: TextView
    private val tripHandler = Handler(Looper.getMainLooper())
    private var secondsElapsed = 0

    private val tripRunnable = object : Runnable {
        override fun run() {
            if (hasActiveOrder) {
                secondsElapsed++
                val mins = secondsElapsed / 60
                val secs = secondsElapsed % 60
                tvChrono.text = String.format("%02d:%02d", mins, secs)
                tripHandler.postDelayed(this, 1000)
            }
        }
    }

    data class OrderInfo(
        val id: String,
        val restaurant: String,
        val amount: String,
        val distance: String,
        val duration: String,
        val address: String,
        val lat: Double,
        val lng: Double
    )

    private val incomingOrdersPool = mutableListOf(
        OrderInfo("N° PZH-881203", "Pizza Hut Agdal", "215 MAD", "3,5 km", "8 min", "Avenue de France, Agdal, Rabat", 33.9850, -6.8480),
        OrderInfo("N° MCD-992110", "McDonald's Agdal", "145 MAD", "2,8 km", "6 min", "Avenue Fal Ould Oumeir, Agdal", 33.9870, -6.8520),
        OrderInfo("N° KFC-441823", "KFC Hay Riad", "210 MAD", "4,1 km", "9 min", "Mahaj Riad, Hay Riad", 33.9510, -6.8650),
        OrderInfo("N° STB-778201", "Starbucks Souissi", "95 MAD", "6,5 km", "14 min", "Route des Zaers, Souissi", 33.9350, -6.8400),
        OrderInfo("N° BKG-112349", "Burger King Rabat", "180 MAD", "3,2 km", "7 min", "Avenue Mohammed V, Centre Ville", 33.0120, -6.8330),
        OrderInfo("N° TCS-554190", "Tacos de Lyon Agdal", "120 MAD", "2,1 km", "5 min", "Rue Sebou, Agdal", 33.9820, -6.8500)
    )

    private var currentOrderIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerLayout)
        val btnMenu = findViewById<View>(R.id.btnMenu)
        val navView = findViewById<NavigationView>(R.id.navView)
        btnOnline = findViewById(R.id.btnOnline)

        layoutActiveTripPanel = findViewById(R.id.layoutActiveTripPanel)
        tvChrono = findViewById(R.id.tvChrono)
        tvDistance = findViewById(R.id.tvDistance)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        btnMenu.setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        // إعداد الزر في البداية (Hors ligne - رمادي ودائري)
        btnOnline.setBackgroundResource(R.drawable.bg_en_ligne)
        btnOnline.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#757575"))
        btnOnline.text = "Hors ligne"

        btnOnline.setOnClickListener {
            if (hasActiveOrder) {
                Toast.makeText(this, "Vous êtes en course, validez la commande d'abord !", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            isOnline = !isOnline
            val cardLayout = findViewById<View>(R.id.layoutIncomingOrderCard)

            if (isOnline) {
                btnOnline.text = "En ligne"
                btnOnline.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0)
                btnOnline.setBackgroundResource(R.drawable.bg_en_ligne)
                btnOnline.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#FF5722"))
                Toast.makeText(this, "Vous êtes en ligne", Toast.LENGTH_SHORT).show()

                btnOnline.postDelayed({
                    if (isOnline && !hasActiveOrder && (cardLayout == null || cardLayout.visibility != View.VISIBLE)) {
                        showNextOrderDialog()
                    }
                }, 3000)

            } else {
                btnOnline.text = "Hors ligne"
                btnOnline.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0)
                btnOnline.setBackgroundResource(R.drawable.bg_en_ligne)
                btnOnline.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#757575"))
                Toast.makeText(this, "Vous êtes hors ligne", Toast.LENGTH_SHORT).show()
                cardLayout?.visibility = View.GONE
            }
        }

        navView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_accueil -> {
                    drawerLayout.closeDrawer(GravityCompat.START)
                    Toast.makeText(this, "Accueil", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_commandes -> {
                    val intent = Intent(this, OrdersActivity::class.java)
                    intent.putExtra("IS_ONLINE", isOnline)
                    startActivity(intent)
                }
                R.id.nav_profil -> {
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_settings -> {
                    drawerLayout.closeDrawer(GravityCompat.START)
                    val intent = Intent(this, SettingsActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_logout -> {
                    drawerLayout.closeDrawer(GravityCompat.START)
                    val intent = Intent(this, LoginActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        findViewById<View>(R.id.btnCall)?.setOnClickListener {
            Toast.makeText(this, "Appel en cours...", Toast.LENGTH_SHORT).show()
        }

        findViewById<View>(R.id.btnZoomIn)?.setOnClickListener {
            if (::mMap.isInitialized) mMap.animateCamera(CameraUpdateFactory.zoomIn())
        }

        findViewById<View>(R.id.btnZoomOut)?.setOnClickListener {
            if (::mMap.isInitialized) mMap.animateCamera(CameraUpdateFactory.zoomOut())
        }

        findViewById<View>(R.id.btnTrace)?.setOnClickListener {
            val order = incomingOrdersPool[currentOrderIndex % incomingOrdersPool.size]
            drawRouteForOrder(order)
            Toast.makeText(this, "Tracé affiché !", Toast.LENGTH_SHORT).show()
        }

        findAndBindDynamicViews(findViewById(android.R.id.content))
        updateDynamicStats()
    }

    private fun findAndBindDynamicViews(view: View) {
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                findAndBindDynamicViews(view.getChildAt(i))
            }
        } else if (view is TextView) {
            val text = view.text.toString()
            if (text.contains("MAD") || text.equals("0 MAD")) {
                tvWellDoneAmount = view
            } else if (text.contains("orders") || text.equals("0 orders")) {
                tvTodayProgressOrders = view
            }
        }
    }

    private fun updateDynamicStats() {
        tvWellDoneAmount?.text = "${OrdersActivity.totalEarnings.toInt()} MAD"
        tvTodayProgressOrders?.text = "${OrdersActivity.completedOrdersCount} orders"
    }

    override fun onResume() {
        super.onResume()
        updateDynamicStats()

        if (OrdersActivity.isOrderValidated) {
            hasActiveOrder = false
            btnOnline.text = if (isOnline) "En ligne" else "Hors ligne"
            btnOnline.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0)
            btnOnline.setBackgroundResource(R.drawable.bg_en_ligne)
            btnOnline.backgroundTintList = android.content.res.ColorStateList.valueOf(
                Color.parseColor(if (isOnline) "#FF5722" else "#757575")
            )

            layoutActiveTripPanel.visibility = View.GONE
            tripHandler.removeCallbacks(tripRunnable)

            currentPolyline?.remove()
            currentPolyline = null

            for (marker in currentMarkers) {
                marker.remove()
            }
            currentMarkers.clear()

            val finishedOrder = incomingOrdersPool[currentOrderIndex % incomingOrdersPool.size]
            driverPosition = LatLng(finishedOrder.lat + 0.002, finishedOrder.lng + 0.002)

            val driverMarker = mMap.addMarker(MarkerOptions().position(driverPosition).title("Ma Position (Livreur)"))
            if (driverMarker != null) {
                currentMarkers.add(driverMarker)
            }
            if (::mMap.isInitialized) {
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(driverPosition, 14f))
            }

            OrdersActivity.isOrderValidated = false
            Toast.makeText(this, "Course validée ! De retour en ligne.", Toast.LENGTH_SHORT).show()

            currentOrderIndex++

            if (isOnline) {
                val rootView = findViewById<View>(android.R.id.content)
                rootView.postDelayed({
                    val cardLayout = findViewById<View>(R.id.layoutIncomingOrderCard)
                    if (!hasActiveOrder && (cardLayout == null || cardLayout.visibility != View.VISIBLE)) {
                        showNextOrderDialog()
                    }
                }, 3000)
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        val driverMarker = mMap.addMarker(MarkerOptions().position(driverPosition).title("Ma Position (Livreur)"))
        if (driverMarker != null) {
            currentMarkers.add(driverMarker)
        }
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(driverPosition, 14f))
    }

    private fun showNextOrderDialog() {
        if (hasActiveOrder) return

        val order = incomingOrdersPool[currentOrderIndex % incomingOrdersPool.size]
        val cardLayout = findViewById<View>(R.id.layoutIncomingOrderCard) ?: return
        cardLayout.visibility = View.VISIBLE

        cardLayout.findViewById<TextView>(R.id.tvCardOrderId)?.text = order.id
        cardLayout.findViewById<TextView>(R.id.tvCardRestaurant)?.text = order.restaurant
        cardLayout.findViewById<TextView>(R.id.tvCardAmount)?.text = order.amount
        cardLayout.findViewById<TextView>(R.id.tvCardDistance)?.text = order.distance
        cardLayout.findViewById<TextView>(R.id.tvCardDuration)?.text = order.duration

        val btnAccept = cardLayout.findViewById<Button>(R.id.btnCardAccept)
        btnAccept?.text = "Accepter"
        btnAccept?.setBackgroundResource(R.drawable.bg_en_ligne)
        btnAccept?.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#FF5722"))
        btnAccept?.setTextColor(Color.WHITE)

        val btnRefuse = cardLayout.findViewById<Button>(R.id.btnCardRefuse)
        btnRefuse?.text = "Refuser"
        btnRefuse?.setBackgroundResource(R.drawable.bg_en_ligne)
        btnRefuse?.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#512DA8"))
        btnRefuse?.setTextColor(Color.WHITE)

        btnAccept?.setOnClickListener {
            hasActiveOrder = true
            btnOnline.text = " En Course"
            btnOnline.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_directions, 0, 0, 0)
            btnOnline.setBackgroundResource(R.drawable.bg_en_ligne)
            btnOnline.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#512DA8"))

            Toast.makeText(this, "Commande acceptée ! En route...", Toast.LENGTH_SHORT).show()
            cardLayout.visibility = View.GONE

            val restaurantLat = order.lat
            val restaurantLng = order.lng
            val clientLat = order.lat + 0.005
            val clientLng = order.lng + 0.006

            val distDriverToResto = calculateDistanceInKm(driverPosition.latitude, driverPosition.longitude, restaurantLat, restaurantLng)
            val distRestoToClient = calculateDistanceInKm(restaurantLat, restaurantLng, clientLat, clientLng)
            val totalDistance = distDriverToResto + distRestoToClient

            secondsElapsed = 0
            tvChrono.text = "00:00"
            tvDistance.text = String.format("%.1f km", totalDistance)

            layoutActiveTripPanel.visibility = View.VISIBLE
            tripHandler.post(tripRunnable)

            OrdersActivity.isDriverOnline = isOnline

            val intent = Intent(this, OrdersActivity::class.java).apply {
                putExtra("ORDER_ID", order.id)
                putExtra("RESTAURANT_NAME", order.restaurant)
                putExtra("AMOUNT", order.amount)
                putExtra("ADDRESS", order.address)
                putExtra("IS_ONLINE", isOnline)
                putExtra("ORDER_STATUS", "Accepté")
            }
            startActivity(intent)

            drawRouteForOrder(order)
        }

        btnRefuse?.setOnClickListener {
            val reasons = arrayOf(
                "Restaurant trop éloigné",
                "Problème de circulation / Embouteillage",
                "Temps d'attente estimé trop long",
                "Autre raison"
            )

            AlertDialog.Builder(this)
                .setTitle("Motif de refus de la commande")
                .setItems(reasons) { _, which ->
                    val chosenReason = reasons[which]

                    if (chosenReason == "Autre raison") {
                        val input = EditText(this).apply {
                            hint = "Écrivez le motif ici..."
                        }
                        AlertDialog.Builder(this)
                            .setTitle("Précisez le motif")
                            .setView(input)
                            .setPositiveButton("Confirmer") { _, _ ->
                                val customReason = input.text.toString().ifEmpty { "Autre raison" }
                                processOrderRefusal(order, customReason, cardLayout)
                            }
                            .setNegativeButton("Annuler", null)
                            .show()
                    } else {
                        processOrderRefusal(order, chosenReason, cardLayout)
                    }
                }
                .setNegativeButton("Annuler", null)
                .show()
        }
    }

    private fun calculateDistanceInKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadius = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadius * c
    }

    private fun processOrderRefusal(order: OrderInfo, reason: String, cardLayout: View) {
        Toast.makeText(this, "Refusé : $reason", Toast.LENGTH_SHORT).show()
        cardLayout.visibility = View.GONE

        OrdersActivity.isDriverOnline = isOnline

        val intent = Intent(this, OrdersActivity::class.java).apply {
            putExtra("ORDER_ID", order.id)
            putExtra("RESTAURANT_NAME", order.restaurant)
            putExtra("AMOUNT", order.amount)
            putExtra("ADDRESS", order.address)
            putExtra("IS_ONLINE", isOnline)
            putExtra("ORDER_STATUS", "Refusé")
        }
        startActivity(intent)

        currentOrderIndex++

        if (isOnline && !hasActiveOrder) {
            val rootView = findViewById<View>(android.R.id.content)
            rootView.postDelayed({
                val currentCard = findViewById<View>(R.id.layoutIncomingOrderCard)
                if (isOnline && !hasActiveOrder && (currentCard == null || currentCard.visibility != View.VISIBLE)) {
                    showNextOrderDialog()
                }
            }, 3000)
        }
    }

    private fun drawRouteForOrder(order: OrderInfo) {
        if (!::mMap.isInitialized) return

        for (marker in currentMarkers) {
            marker.remove()
        }
        currentMarkers.clear()

        val driverMarker = mMap.addMarker(MarkerOptions().position(driverPosition).title("Ma Position (Livreur)"))
        val pointB = LatLng(order.lat, order.lng)
        val pointC = LatLng(order.lat + 0.005, order.lng + 0.006)

        val markerB = mMap.addMarker(MarkerOptions().position(pointB).title(order.restaurant))
        val markerC = mMap.addMarker(MarkerOptions().position(pointC).title("Client Destination"))

        if (driverMarker != null) currentMarkers.add(driverMarker)
        if (markerB != null) currentMarkers.add(markerB)
        if (markerC != null) currentMarkers.add(markerC)

        currentPolyline?.remove()
        currentPolyline = mMap.addPolyline(
            PolylineOptions()
                .add(driverPosition, pointB, pointC)
                .width(10f)
                .color(Color.parseColor("#FF5722"))
        )
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(pointB, 13f))
    }
}